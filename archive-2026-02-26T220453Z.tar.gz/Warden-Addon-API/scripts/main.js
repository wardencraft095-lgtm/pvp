import { system, world } from "@minecraft/server";
import { http, HttpHeader, HttpRequest, HttpRequestMethod } from "@minecraft/server-net";
import { loadPlugins } from "./pluginManager.js";

/**
 * BRIDGE HTTP v3.5 - COMANDOS NATIVOS RESTAURADOS
 */

// Inicializa o sistema de plugins
loadPlugins().catch(console.error);

// CONFIGURAÇÕES
const SECRET_TOKEN = "AKSNG390573AJGASGJ";
const SERVER_URL = "https://warden3000.discloud.app";
const POLL_INTERVAL = 100; // 100 ticks = 5 segundos

console.log("[Bridge HTTP] Iniciando script de ponte v3.5...");

// Cache de Ranks recebidos do Essentials
let cachedRankData = { ranks: [], playerRanks: {} };

// Escuta a sincronização vinda do Essentials
system.afterEvents.scriptEventReceive.subscribe(({ id, message }) => {
    if (id === "mce:sync_ranks_to_bridge") {
        try {
            cachedRankData = JSON.parse(message);
        } catch (e) {}
    }
});

/**
 * Função para buscar e executar comandos do Discord
 */
async function fetchCommands() {
    try {
        const response = await http.get(`${SERVER_URL}/get-commands?token=${SECRET_TOKEN}`);
        if (response.status !== 200) return;
        
        const data = JSON.parse(response.body);
        if (!data || !data.commands || data.commands.length === 0) return;

        for (const cmdObj of data.commands) {
            const { command, args, native } = cmdObj;
            
            system.run(() => {
                if (native) {
                    let finalCmd = "";
                    switch (command) {
                        case "whitelist":
                            const [wAcao, wPlayer] = args.split('|');
                            if (wAcao === "on") finalCmd = "whitelist on";
                            else if (wAcao === "off") finalCmd = "whitelist off";
                            else if (wAcao === "add") finalCmd = `whitelist add "${wPlayer}"`;
                            else if (wAcao === "remove") finalCmd = `whitelist remove "${wPlayer}"`;
                            break;
                        case "freeze":
                            const [fPlayer, fState] = args.split('|');
                            const permission = fState === "true" ? "disabled" : "enabled";
                            try {
                                world.getDimension("overworld").runCommand(`inputpermission set "${fPlayer}" movement ${permission}`);
                                world.getDimension("overworld").runCommand(`inputpermission set "${fPlayer}" camera ${permission}`);
                                console.log(`[Bridge HTTP] Jogador ${fPlayer} ${fState === "true" ? "congelado" : "descongelado"}.`);
                            } catch(e) {}
                            break;
                        case "gamerule":
                            const [rule, val] = args.split('|');
                            finalCmd = `gamerule ${rule} ${val}`;
                            break;
                        case "difficulty":
                            finalCmd = `difficulty ${args}`;
                            break;
                        case "clearinv": 
                            finalCmd = `clear "${args}"`; 
                            break;
                        case "giveitem":
                            const [p, item, q] = args.split('|');
                            finalCmd = `give "${p}" ${item} ${q}`;
                            break;
                        case "settime": 
                            finalCmd = `time set ${args}`; 
                            break;
                        case "tp":
                            const [tpP, x, y, z] = args.split('|');
                            finalCmd = `tp "${tpP}" ${x} ${y} ${z}`;
                            break;
                    }
                    if (finalCmd) {
                        try {
                            world.getDimension("overworld").runCommand(finalCmd);
                            console.log(`[Bridge HTTP] Executado comando nativo: ${finalCmd}`);
                        } catch (e) {
                            console.error(`[Bridge HTTP] Erro ao executar comando nativo: ${e}`);
                        }
                    }
                } else {
                    // Comandos Essentials via ScriptEvent mce:ID
                    system.sendScriptEvent(`mce:${command}`, args);
                    console.log(`[Bridge HTTP] ScriptEvent enviado: mce:${command} | Args: ${args}`);
                }
            });
        }
    } catch (e) {
        console.error(`[Bridge HTTP] Erro ao buscar comandos: ${e}`);
    }
}

/**
 * Função para enviar status e ranks ao Bot
 */
async function syncToBot() {
    try {
        const players = world.getAllPlayers();
        const playerNames = players.map(p => p.name);
        
        // Envia Status
        const statusReq = new HttpRequest(`${SERVER_URL}/update-status?token=${SECRET_TOKEN}`);
        statusReq.setMethod(HttpRequestMethod.Post);
        statusReq.setHeaders([new HttpHeader("Content-Type", "application/json")]);
        statusReq.setBody(JSON.stringify({
            players: players.length,
            playerList: playerNames,
            tps: 20
        }));
        await http.request(statusReq);

        // Envia Ranks
        const rankReq = new HttpRequest(`${SERVER_URL}/update-ranks?token=${SECRET_TOKEN}`);
        rankReq.setMethod(HttpRequestMethod.Post);
        rankReq.setHeaders([new HttpHeader("Content-Type", "application/json")]);
        rankReq.setBody(JSON.stringify(cachedRankData));
        await http.request(rankReq);

    } catch (e) {}
}

// Loop principal de sincronização
system.runInterval(() => {
    fetchCommands();
    syncToBot();
}, POLL_INTERVAL);

console.log("[Bridge HTTP] Monitorando: " + SERVER_URL);
