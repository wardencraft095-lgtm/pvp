
import { system, world } from "@minecraft/server";

/**
 * Warden Plugin Loader
 * Gerencia o carregamento de plugins na pasta scripts/plugins/
 */

export async function loadPlugins() {
    console.log("[Warden Plugins] Iniciando carregamento de plugins...");
    
    // No Minecraft Bedrock, imports dinâmicos (import()) dentro de blocos try/catch 
    // às vezes falham se o arquivo não estiver perfeitamente resolvido.
    // A forma mais estável é importar o index.js que contém os imports estáticos.
    
    try {
        await import("./plugins/index.js");
        console.log("[Warden Plugins] Sistema de plugins inicializado com sucesso.");
    } catch (e) {
        // Se houver um erro de sintaxe em QUALQUER plugin importado pelo index.js,
        // o erro cairá aqui.
        console.error("§c[Warden Plugins] ERRO AO CARREGAR PLUGINS:§r");
        console.error("§e" + e + "§r");
        console.error("§7Verifique se há erros de sintaxe nos seus arquivos em scripts/plugins/§r");
    }
}
