
/**
 * PLUGIN ARENA 1v1 - COM ITENS PERSONALIZADOS
 * Adaptado do original por Manus AI
 */

import { world, system } from "@minecraft/server";

/* ===== CONFIGURE AS COORDENADAS AQUI ===== */
const SPAWN = { x: -681, y: 74, z: 1028 };      
const ARENA_P1 = { x: 10126, y: 62, z: 9975 };  
const ARENA_P2 = { x: 10126, y: 62, z: 9914 };  
const ARENA_CENTER = { x: 10126, y: 62, z: 9944 }; 
const ARENA_RADIUS = 100; 

const TAG_DISCONNECTED = "pvp_disconnected"; 
const TAG_IN_FIGHT = "pvp_in_fight"; 
const TAG_ARENA_ALLOWED = "pvp_allowed"; 

/* ===== ESTADO DO SISTEMA ===== */
let queue = [];
let fighting = [];
let arenaBusy = false;
let fightActive = false;
let fightStartTime = null;
let positionCheckInterval = null;

/* ===== FUNÇÕES AUXILIARES ===== */

function isValidEntity(entity) {
    if (!entity) return false;
    try { return !!entity.typeId; } catch (e) { return false; }
}

function getPlayerName(player) {
    if (!player) return "Desconhecido";
    try { return player.name || "Desconhecido"; } catch (e) { return "Desconhecido"; }
}

function addTag(player, tag) {
    if (isValidEntity(player)) try { player.addTag(tag); } catch (e) {}
}

function removeTag(player, tag) {
    if (isValidEntity(player)) try { player.removeTag(tag); } catch (e) {}
}

function hasTag(player, tag) {
    if (!isValidEntity(player)) return false;
    try { return player.hasTag(tag); } catch (e) { return false; }
}

function runCommandForPlayer(player, command) {
    if (!isValidEntity(player)) return;
    try {
        const safeName = getPlayerName(player).replace(/"/g, '\\"');
        world.getDimension("overworld").runCommand(`execute as "${safeName}" at @s run ${command}`);
    } catch (e) {}
}

function clearAllInventory(player) {
    if (!isValidEntity(player)) return;
    try {
        const container = player.getComponent("inventory")?.container;
        if (container) {
            for (let i = 0; i < container.size; i++) container.setItem(i, undefined);
        }
        runCommandForPlayer(player, "replaceitem entity @s slot.armor.head 0 air");
        runCommandForPlayer(player, "replaceitem entity @s slot.armor.chest 0 air");
        runCommandForPlayer(player, "replaceitem entity @s slot.armor.legs 0 air");
        runCommandForPlayer(player, "replaceitem entity @s slot.armor.feet 0 air");
    } catch (e) {}
}

function isEmpty(player) {
    if (!isValidEntity(player)) return true;
    try {
        const container = player.getComponent("inventory")?.container;
        if (!container) return true;
        for (let i = 0; i < container.size; i++) {
            if (container.getItem(i)) return false;
        }
        return true;
    } catch (e) { return true; }
}

function isInArena(player) {
    if (!isValidEntity(player)) return false;
    const pos = player.location;
    const dist = Math.sqrt(Math.pow(pos.x - ARENA_CENTER.x, 2) + Math.pow(pos.z - ARENA_CENTER.z, 2));
    return dist <= ARENA_RADIUS;
}

/* ===== KIT PERSONALIZADO ===== */
function giveCustomKit(player) {
    if (!isValidEntity(player)) return;
    
    // Armadura de Diamante com Encantamentos Básicos (via comando)
    runCommandForPlayer(player, "replaceitem entity @s slot.armor.head 0 diamond_helmet");
    runCommandForPlayer(player, "replaceitem entity @s slot.armor.chest 0 diamond_chestplate");
    runCommandForPlayer(player, "replaceitem entity @s slot.armor.legs 0 diamond_leggings");
    runCommandForPlayer(player, "replaceitem entity @s slot.armor.feet 0 diamond_boots");
    
    // Itens de Combate
    runCommandForPlayer(player, "give @s diamond_sword 1");
    runCommandForPlayer(player, "give @s golden_apple 16");
    runCommandForPlayer(player, "give @s enchanted_golden_apple 1");
    runCommandForPlayer(player, "give @s ender_pearl 16");
    runCommandForPlayer(player, "give @s bow 1");
    runCommandForPlayer(player, "give @s arrow 64");
    runCommandForPlayer(player, "give @s steak 64");
}

/* ===== LÓGICA DE JOGO ===== */

function endFight(winner, loser, reason = "NORMAL") {
    if (positionCheckInterval) {
        system.clearRun(positionCheckInterval);
        positionCheckInterval = null;
    }

    const winnerName = winner ? getPlayerName(winner) : "Desconhecido";
    const loserName = loser ? getPlayerName(loser) : "Desconhecido";

    if (winner) {
        removeTag(winner, TAG_IN_FIGHT);
        removeTag(winner, TAG_ARENA_ALLOWED);
        clearAllInventory(winner);
        runCommandForPlayer(winner, `tp @s ${SPAWN.x} ${SPAWN.y} ${SPAWN.z}`);
    }
    if (loser) {
        removeTag(loser, TAG_IN_FIGHT);
        removeTag(loser, TAG_ARENA_ALLOWED);
        clearAllInventory(loser);
        runCommandForPlayer(loser, `tp @s ${SPAWN.x} ${SPAWN.y} ${SPAWN.z}`);
    }

    world.sendMessage(`§a🏆 §f${winnerName} §avenceu o duelo 1v1 contra §f${loserName}!`);
    
    arenaBusy = false;
    fightActive = false;
    fighting = [];
}

function startFight() {
    if (fighting.length < 2) return;
    const [p1, p2] = fighting;

    addTag(p1, TAG_IN_FIGHT);
    addTag(p1, TAG_ARENA_ALLOWED);
    addTag(p2, TAG_IN_FIGHT);
    addTag(p2, TAG_ARENA_ALLOWED);

    runCommandForPlayer(p1, `tp @s ${ARENA_P1.x} ${ARENA_P1.y} ${ARENA_P1.z}`);
    runCommandForPlayer(p2, `tp @s ${ARENA_P2.x} ${ARENA_P2.y} ${ARENA_P2.z}`);

    giveCustomKit(p1);
    giveCustomKit(p2);

    fightActive = true;
    fightStartTime = system.currentTick;
    world.sendMessage("§6⚔️ O DUELO COMEÇOU! ⚔️");
}

system.afterEvents.scriptEventReceive.subscribe((event) => {
    if (event.id === "manus:1v1_itens") {
        const player = event.sourceEntity;
        if (!player || player.typeId !== "minecraft:player") return;

        if (queue.includes(player) || fighting.includes(player)) {
            player.sendMessage("§cVocê já está na fila ou em luta!");
            return;
        }

        if (!isEmpty(player)) {
            player.sendMessage("§cEsvazie seu inventário para entrar no 1v1!");
            return;
        }

        queue.push(player);
        player.sendMessage("§aVocê entrou na fila para o 1v1 com itens!");
    }
});

system.runInterval(() => {
    if (!arenaBusy && queue.length >= 2) {
        arenaBusy = true;
        fighting = [queue.shift(), queue.shift()];
        startFight();
    }
}, 20);

world.afterEvents.entityDie.subscribe((event) => {
    const deadEntity = event.deadEntity;
    if (deadEntity.typeId !== "minecraft:player") return;

    if (fighting.includes(deadEntity)) {
        const winner = fighting.find(p => p !== deadEntity);
        endFight(winner, deadEntity);
    }
});
