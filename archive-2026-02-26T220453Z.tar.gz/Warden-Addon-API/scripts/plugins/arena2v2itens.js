
/**
 * PLUGIN ARENA 2v2 - COM ITENS PERSONALIZADOS
 * Adaptado do original por Manus AI
 */

import { world, system } from "@minecraft/server";

/* ===== CONFIGURE AS COORDENADAS AQUI ===== */
const SPAWN = { x: -681, y: 74, z: 1028 };      
const TEAM_A_SPAWN = { x: 10126, y: 62, z: 9975 };  
const TEAM_B_SPAWN = { x: 10126, y: 62, z: 9914 };  
const ARENA_CENTER = { x: 10126, y: 62, z: 9944 }; 
const ARENA_RADIUS = 100; 

const TAG_IN_FIGHT = "pvp_in_fight"; 
const TAG_TEAM_A = "team_a";
const TAG_TEAM_B = "team_b";

/* ===== ESTADO DO SISTEMA ===== */
let queue = [];
let teamA = [];
let teamB = [];
let arenaBusy = false;

/* ===== FUNÇÕES AUXILIARES ===== */

function isValidEntity(entity) {
    if (!entity) return false;
    try { return !!entity.typeId; } catch (e) { return false; }
}

function runCommandForPlayer(player, command) {
    if (!isValidEntity(player)) return;
    try {
        const safeName = player.name.replace(/"/g, '\\"');
        world.getDimension("overworld").runCommand(`execute as "${safeName}" at @s run ${command}`);
    } catch (e) {}
}

function clearAllInventory(player) {
    if (!isValidEntity(player)) return;
    try {
        const container = player.getComponent("inventory")?.container;
        if (container) {
            for (let i = 0; i < container.size; i++) container.setItem(i, undefined);
        }
        runCommandForPlayer(player, "replaceitem entity @s slot.armor.head 0 air");
        runCommandForPlayer(player, "replaceitem entity @s slot.armor.chest 0 air");
        runCommandForPlayer(player, "replaceitem entity @s slot.armor.legs 0 air");
        runCommandForPlayer(player, "replaceitem entity @s slot.armor.feet 0 air");
    } catch (e) {}
}

/* ===== KIT PERSONALIZADO ===== */
function giveCustomKit(player) {
    if (!isValidEntity(player)) return;
    
    // Armadura de Diamante Completa
    runCommandForPlayer(player, "replaceitem entity @s slot.armor.head 0 diamond_helmet");
    runCommandForPlayer(player, "replaceitem entity @s slot.armor.chest 0 diamond_chestplate");
    runCommandForPlayer(player, "replaceitem entity @s slot.armor.legs 0 diamond_leggings");
    runCommandForPlayer(player, "replaceitem entity @s slot.armor.feet 0 diamond_boots");
    
    // Itens de Combate
    runCommandForPlayer(player, "give @s netherite_sword 1");
    runCommandForPlayer(player, "give @s golden_apple 32");
    runCommandForPlayer(player, "give @s enchanted_golden_apple 2");
    runCommandForPlayer(player, "give @s ender_pearl 16");
    runCommandForPlayer(player, "give @s splash_potion 1 22"); // Poção de Cura II
    runCommandForPlayer(player, "give @s steak 64");
}

/* ===== LÓGICA DE JOGO ===== */

function endFight(winningTeam) {
    const allPlayers = [...teamA, ...teamB];
    
    allPlayers.forEach(p => {
        if (isValidEntity(p)) {
            p.removeTag(TAG_IN_FIGHT);
            p.removeTag(TAG_TEAM_A);
            p.removeTag(TAG_TEAM_B);
            clearAllInventory(p);
            runCommandForPlayer(p, `tp @s ${SPAWN.x} ${SPAWN.y} ${SPAWN.z}`);
        }
    });

    world.sendMessage(`§a🏆 §fEquipe ${winningTeam === 'A' ? '§bAZUL' : '§cVERMELHA'} §avenceu o duelo 2v2 com itens!`);
    
    arenaBusy = false;
    teamA = [];
    teamB = [];
}

function startFight() {
    teamA.forEach(p => {
        p.addTag(TAG_IN_FIGHT);
        p.addTag(TAG_TEAM_A);
        runCommandForPlayer(p, `tp @s ${TEAM_A_SPAWN.x} ${TEAM_A_SPAWN.y} ${TEAM_A_SPAWN.z}`);
        giveCustomKit(p);
        p.sendMessage("§bVocê está na Equipe AZUL!");
    });

    teamB.forEach(p => {
        p.addTag(TAG_IN_FIGHT);
        p.addTag(TAG_TEAM_B);
        runCommandForPlayer(p, `tp @s ${TEAM_B_SPAWN.x} ${TEAM_B_SPAWN.y} ${TEAM_B_SPAWN.z}`);
        giveCustomKit(p);
        p.sendMessage("§cVocê está na Equipe VERMELHA!");
    });

    world.sendMessage("§6⚔️ O DUELO 2v2 COM ITENS COMEÇOU! ⚔️");
}

system.afterEvents.scriptEventReceive.subscribe((event) => {
    if (event.id === "manus:2v2_itens") {
        const player = event.sourceEntity;
        if (!player || player.typeId !== "minecraft:player") return;

        if (queue.includes(player) || teamA.includes(player) || teamB.includes(player)) {
            player.sendMessage("§cVocê já está na fila!");
            return;
        }

        queue.push(player);
        player.sendMessage("§aVocê entrou na fila para o 2v2 com itens!");
        world.sendMessage(`§e${player.name} entrou na fila 2v2 Itens (${queue.length}/4)`);
    }
});

system.runInterval(() => {
    if (!arenaBusy && queue.length >= 4) {
        arenaBusy = true;
        teamA = [queue.shift(), queue.shift()];
        teamB = [queue.shift(), queue.shift()];
        startFight();
    }
}, 20);

world.afterEvents.entityDie.subscribe((event) => {
    const deadEntity = event.deadEntity;
    if (deadEntity.typeId !== "minecraft:player") return;

    if (teamA.includes(deadEntity) || teamB.includes(deadEntity)) {
        const teamALive = teamA.filter(p => isValidEntity(p) && p.getComponent("health").currentValue > 0);
        const teamBLive = teamB.filter(p => isValidEntity(p) && p.getComponent("health").currentValue > 0);

        if (teamALive.length === 0) endFight('B');
        else if (teamBLive.length === 0) endFight('A');
    }
});
