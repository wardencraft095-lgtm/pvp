
/**
 * INDEX DE PLUGINS
 * Importe seus novos plugins aqui para que sejam carregados pelo sistema.
 */

import "./arena1v1.js";
import "./arena2v2.js";
import "./arena1v1itens.js";
import "./arena2v2itens.js";

// import "./meu_novo_plugin.js";

console.log("[Warden Plugins] Todos os plugins do index foram carregados.");
