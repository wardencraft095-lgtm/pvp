import { world, system } from "@minecraft/server";

/**
 * PLUGIN ARENA - ADAPTADO PARA /scriptevent manus:1v1
 * Criado por Manus AI
 */

/* ===== CONFIGURE AS COORDENADAS AQUI ===== */
const SPAWN = { x: -681, y: 74, z: 1028 };      // Local para onde os jogadores voltam após a luta
const ARENA_P1 = { x: 10126, y: 62, z: 9975 };  // Posição de spawn do Jogador 1 na arena
const ARENA_P2 = { x: 10126, y: 62, z: 9914 };  // Posição de spawn do Jogador 2 na arena
const ARENA_CENTER = { x: 10126, y: 62, z: 9944 }; // Centro da arena (ponto médio)
const ARENA_RADIUS = 100; // Raio de tolerância (em blocos)

// Tags para controle
const TAG_DISCONNECTED = "pvp_disconnected"; // Tag para jogadores que desconectaram durante luta
const TAG_IN_FIGHT = "pvp_in_fight"; // Tag para jogadores em luta
const TAG_ARENA_ALLOWED = "pvp_allowed"; // Tag para jogadores autorizados a estar na arena

/* ===== ESTADO DO SISTEMA ===== */
let queue = [];
let fighting = [];
let arenaBusy = false;
let actionBarInterval = null;
let fightStartTime = null;
let positionCheckInterval = null;
let fightActive = false;

/* ===== FUNÇÕES AUXILIARES ===== */

/**
 * Verifica se uma entidade ainda é válida
 */
function isValidEntity(entity) {
    if (!entity) return false;
    try {
        const test = entity.typeId;
        return true;
    } catch (e) {
        return false;
    }
}

/**
 * Obtém nome seguro do jogador
 */
function getPlayerName(player) {
    if (!player) return "Desconhecido";
    try {
        return player.name || "Desconhecido";
    } catch (e) {
        return "Desconhecido";
    }
}

/**
 * Adiciona tag a um jogador
 */
function addTag(player, tag) {
    if (!player || !isValidEntity(player)) return;
    try {
        player.addTag(tag);
    } catch (e) {}
}

/**
 * Remove tag de um jogador
 */
function removeTag(player, tag) {
    if (!player || !isValidEntity(player)) return;
    try {
        player.removeTag(tag);
    } catch (e) {}
}

/**
 * Verifica se jogador tem tag
 */
function hasTag(player, tag) {
    if (!player || !isValidEntity(player)) return false;
    try {
        return player.hasTag(tag);
    } catch (e) {
        return false;
    }
}

/**
 * Verifica se o jogador está autorizado a estar na arena
 */
function isAllowedInArena(player) {
    if (!player || !isValidEntity(player)) return false;
    
    // Jogadores em luta têm permissão
    if (hasTag(player, TAG_IN_FIGHT)) return true;
    
    // Jogadores com tag de autorização (por segurança)
    if (hasTag(player, TAG_ARENA_ALLOWED)) return true;
    
    return false;
}

/**
 * Remove jogador não autorizado da arena
 */
function removeUnauthorizedFromArena(player) {
    if (!player || !isValidEntity(player)) return false;
    
    if (isInArena(player) && !isAllowedInArena(player)) {
        const playerName = getPlayerName(player);
        console.log(`[PvP System] Jogador não autorizado ${playerName} detectado na arena. Teleportando...`);
        
        // Teleporta para o spawn
        runCommandForPlayer(player, `tp @s ${SPAWN.x} ${SPAWN.y} ${SPAWN.z}`);
        
        // Avisa o jogador
        showTitle(player, "§c§lACESSO NEGADO!", "§fÁrea restrita ao 1v1!");
        player.sendMessage("§c❌ Você não tem permissão para estar na arena! Use /scriptevent manus:1v1 para entrar na fila.");
        
        // Toca som de erro
        runCommandForPlayer(player, "playsound random.break @s");
        
        return true;
    }
    
    return false;
}

/**
 * Verifica e limpa jogador que reconectou
 */
function checkAndCleanReconnectedPlayer(player) {
    if (!player || !isValidEntity(player)) return false;
    
    try {
        if (hasTag(player, TAG_DISCONNECTED)) {
            const playerName = getPlayerName(player);
            console.log(`[PvP System] Jogador ${playerName} reconectou com tag. Aplicando limpeza.`);
            
            clearAllInventory(player);
            runCommandForPlayer(player, `tp @s ${SPAWN.x} ${SPAWN.y} ${SPAWN.z}`);
            removeTag(player, TAG_DISCONNECTED);
            
            system.runTimeout(() => {
                if (isValidEntity(player)) {
                    showTitle(player, "§c§lRECONEXÃO", "§fVocê estava em uma luta!");
                    player.sendMessage("§eℹ️ Você desconectou durante uma luta. Seu inventário foi limpo e você foi teleportado para o spawn.");
                    runCommandForPlayer(player, "playsound random.levelup @s");
                }
            }, 20);
            
            return true;
        }
        
        if (hasTag(player, TAG_IN_FIGHT) && !fighting.includes(player)) {
            removeTag(player, TAG_IN_FIGHT);
            removeTag(player, TAG_ARENA_ALLOWED);
            clearAllInventory(player);
            runCommandForPlayer(player, `tp @s ${SPAWN.x} ${SPAWN.y} ${SPAWN.z}`);
            return true;
        }
        
        return false;
    } catch (e) {
        return false;
    }
}

/**
 * Limpa tags de todos os jogadores online
 */
function cleanupAllTags() {
    try {
        for (const player of world.getAllPlayers()) {
            if (!isValidEntity(player)) continue;
            
            if (hasTag(player, TAG_DISCONNECTED)) {
                removeTag(player, TAG_DISCONNECTED);
            }
            
            if (hasTag(player, TAG_IN_FIGHT) && !fighting.includes(player)) {
                removeTag(player, TAG_IN_FIGHT);
                removeTag(player, TAG_ARENA_ALLOWED);
                clearAllInventory(player);
                runCommandForPlayer(player, `tp @s ${SPAWN.x} ${SPAWN.y} ${SPAWN.z}`);
            }
        }
    } catch (e) {}
}

/**
 * Calcula a distância entre dois pontos
 */
function getDistance(pos1, pos2) {
    const dx = pos1.x - pos2.x;
    const dy = pos1.y - pos2.y;
    const dz = pos1.z - pos2.z;
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
}

/**
 * Verifica se o jogador está dentro da arena
 */
function isInArena(player) {
    if (!isValidEntity(player)) return false;
    
    try {
        const playerPos = player.location;
        if (!playerPos) return false;
        
        const distance = getDistance(playerPos, ARENA_CENTER);
        return distance <= ARENA_RADIUS;
    } catch (e) {
        return false;
    }
}

/**
 * Limpa todo o inventário e armadura do jogador
 */
function clearAllInventory(player) {
    if (!isValidEntity(player)) return;
    
    try {
        const container = player.getComponent("inventory")?.container;
        if (container) {
            for (let i = 0; i < container.size; i++) {
                container.setItem(i, undefined);
            }
        }
        
        runCommandForPlayer(player, "replaceitem entity @s slot.armor.head 0 air");
        runCommandForPlayer(player, "replaceitem entity @s slot.armor.chest 0 air");
        runCommandForPlayer(player, "replaceitem entity @s slot.armor.legs 0 air");
        runCommandForPlayer(player, "replaceitem entity @s slot.armor.feet 0 air");
    } catch (e) {}
}

/**
 * Verifica se o inventário do jogador está vazio
 */
function isEmpty(player) {
    if (!isValidEntity(player)) return true;
    
    try {
        const container = player.getComponent("inventory")?.container;
        if (!container) return true;
        for (let i = 0; i < container.size; i++) {
            if (container.getItem(i)) return false;
        }
        return true;
    } catch (e) {
        return true;
    }
}

/**
 * Remove jogador da fila
 */
function removeFromQueue(player, reason = "Você pegou um item!") {
    if (!player) return false;
    
    const playerName = getPlayerName(player);
    
    if (queue.includes(player)) {
        queue = queue.filter(p => p !== player);
        if (isValidEntity(player)) {
            try {
                showTitle(player, "§c§lFILA CANCELADA", `§f${reason}`);
            } catch (e) {}
        }
        world.sendMessage(`§c❌ §f${playerName} §cfoi removido da fila - ${reason}`);
        return true;
    }
    return false;
}

/**
 * Executa um comando no contexto do mundo
 */
function runCommandForPlayer(player, command) {
    if (!isValidEntity(player)) return;
    
    try {
        const dimension = world.getDimension("overworld");
        if (dimension) {
            const safeName = getPlayerName(player).replace(/"/g, '\\"');
            dimension.runCommand(`execute as "${safeName}" at "${safeName}" run ${command}`);
        }
    } catch (e) {}
}

/**
 * Entrega o kit de combate
 */
function giveKit(player) {
    if (!isValidEntity(player)) return;
    
    runCommandForPlayer(player, "give @s iron_sword 1");
    runCommandForPlayer(player, "give @s cooked_beef 8");
    runCommandForPlayer(player, "replaceitem entity @s slot.armor.head 0 iron_helmet");
    runCommandForPlayer(player, "replaceitem entity @s slot.armor.chest 0 iron_chestplate");
    runCommandForPlayer(player, "replaceitem entity @s slot.armor.legs 0 iron_leggings");
    runCommandForPlayer(player, "replaceitem entity @s slot.armor.feet 0 iron_boots");
}

/**
 * Mostra título para um jogador
 */
function showTitle(player, text, subtitle = "") {
    if (!isValidEntity(player)) return;
    
    if (subtitle) {
        runCommandForPlayer(player, `title @s title ${text}`);
        runCommandForPlayer(player, `title @s subtitle ${subtitle}`);
    } else {
        runCommandForPlayer(player, `title @s title ${text}`);
    }
}

/**
 * Mostra action bar para um jogador
 */
function showActionBar(player, text) {
    if (!isValidEntity(player)) return;
    runCommandForPlayer(player, `title @s actionbar ${text}`);
}

/**
 * Verifica se a arena está ocupada
 */
function getArenaStatus() {
    if (!arenaBusy) {
        return { busy: false, message: "§aArena disponível!" };
    }
    
    if (fighting.length === 2) {
        const status = fightActive ? "§cEm luta" : "§ePreparando";
        const validFighters = fighting.filter(p => p && isValidEntity(p));
        const names = validFighters.map(p => getPlayerName(p)).join(" §7vs §f");
        
        return { 
            busy: true, 
            message: `${status}: §f${names}`,
            players: fighting,
            active: fightActive
        };
    }
    
    return { busy: true, message: "§cArena ocupada no momento." };
}

/**
 * Finaliza a luta e limpa os estados
 */
function endFight(winner, loser, reason = "NORMAL") {
    if (positionCheckInterval) {
        system.clearRun(positionCheckInterval);
        positionCheckInterval = null;
    }
    
    const winnerName = winner ? getPlayerName(winner) : "Desconhecido";
    const loserName = loser ? getPlayerName(loser) : "Desconhecido";
    
    // Remove tags de luta e autorização
    if (winner && isValidEntity(winner)) {
        removeTag(winner, TAG_IN_FIGHT);
        removeTag(winner, TAG_ARENA_ALLOWED);
    }
    if (loser && isValidEntity(loser)) {
        removeTag(loser, TAG_IN_FIGHT);
        removeTag(loser, TAG_ARENA_ALLOWED);
    }
    
    if (reason === "WO_QUITOU") {
        if (winner) {
            world.sendMessage(`§a🏆 §f${winnerName} §avenceu por WO - Adversário desconectou!`);
        } else {
            world.sendMessage(`§c⚠️ Luta cancelada - jogadores desconectaram!`);
        }
    } else if (reason === "WO_SAIU_ARENA") {
        world.sendMessage(`§a🏆 §f${winnerName} §avenceu por WO - §f${loserName} §csaiu da arena!`);
    } else if (reason === "AMBOS_FORA" || reason === "TODOS_QUITARAM") {
        world.sendMessage(`§c⚠️ Luta cancelada - ambos os jogadores saíram da arena!`);
    } else if (reason === "TELEPORT_SAIU") {
        world.sendMessage(`§c⚠️ Luta cancelada - jogador foi teleportado para fora da arena!`);
    } else if (reason === "TEMPO_ESGOTADO") {
        world.sendMessage(`§c⚠️ Tempo esgotado! Luta finalizada.`);
    } else if (winner && loser) {
        world.sendMessage(`§a🏆 §f${winnerName} §avenceu o duelo contra §f${loserName}!`);
    } else if (winner && !loser) {
        world.sendMessage(`§e⚠️ §f${winnerName} §evenceu por WO!`);
    } else {
        world.sendMessage(`§c⚠️ Luta cancelada!`);
    }

    if (winner && isValidEntity(winner)) {
        try {
            clearAllInventory(winner);
            runCommandForPlayer(winner, `tp @s ${SPAWN.x} ${SPAWN.y} ${SPAWN.z}`);
            showTitle(winner, "§a§lVITÓRIA!", reason.includes("WO") ? "§fPor WO!" : "§fParabéns!");
        } catch (e) {}
    }
    
    if (loser && isValidEntity(loser)) {
        try {
            clearAllInventory(loser);
            runCommandForPlayer(loser, `tp @s ${SPAWN.x} ${SPAWN.y} ${SPAWN.z}`);
            if (reason === "WO_SAIU_ARENA") {
                showTitle(loser, "§c§lDERROTA!", "§fVocê saiu da arena!");
            } else {
                showTitle(loser, "§c§lDERROTA!", "§fTente novamente!");
            }
        } catch (e) {}
    }

    arenaBusy = false;
    fightActive = false;
    fighting = [];
    fightStartTime = null;
    
    world.sendMessage(`§a✅ Arena liberada! ${queue.length} jogador(es) na fila.`);
}

/* ===== LOOP DE VERIFICAÇÃO DE POSIÇÃO ===== */

function startPositionCheck() {
    if (positionCheckInterval) system.clearRun(positionCheckInterval);
    
    positionCheckInterval = system.runInterval(() => {
        try {
            if (!arenaBusy || fighting.length === 0 || !fightActive) {
                return;
            }
            
            const validFighters = fighting.filter(p => p && isValidEntity(p));
            
            if (validFighters.length === 0) {
                world.sendMessage("§c⚠️ Todos os jogadores saíram! Luta cancelada.");
                endFight(null, null, "TODOS_QUITARAM");
                return;
            }
            
            if (validFighters.length === 1) {
                const winner = validFighters[0];
                const loser = fighting.find(p => p !== winner);
                endFight(winner, loser, "WO_QUITOU");
                return;
            }
            
            const [p1, p2] = fighting;
            let playersOutOfArena = [];
            
            for (const player of [p1, p2]) {
                if (!player || !isValidEntity(player)) continue;
                
                if (!isInArena(player)) {
                    playersOutOfArena.push(player);
                    try {
                        showTitle(player, "§c§lFORA DA ARENA!", "§fVolte ou perderá a luta!");
                    } catch (e) {}
                }
            }
            
            if (playersOutOfArena.length > 0) {
                if (playersOutOfArena.length === 2) {
                    world.sendMessage("§c⚠️ Ambos os jogadores saíram da arena! Luta cancelada.");
                    endFight(null, null, "AMBOS_FORA");
                } else {
                    const playerOut = playersOutOfArena[0];
                    const winner = fighting.find(p => p !== playerOut && isValidEntity(p));
                    
                    if (winner) {
                        endFight(winner, playerOut, "WO_SAIU_ARENA");
                    }
                }
            }
        } catch (e) {
            if (arenaBusy) {
                endFight(null, null, "ERRO_VERIFICACAO");
            }
        }
    }, 20);
}

/* ===== LOOP PRINCIPAL ===== */

actionBarInterval = system.runInterval(() => {
    try {
        queue = queue.filter(p => p && isValidEntity(p));
        
        for (const player of world.getAllPlayers()) {
            if (!isValidEntity(player)) continue;
            
            // VERIFICAÇÃO DE SEGURANÇA: Remove não autorizados da arena
            if (isInArena(player) && !isAllowedInArena(player)) {
                removeUnauthorizedFromArena(player);
                continue;
            }
            
            if (queue.includes(player)) {
                const position = queue.indexOf(player) + 1;
                const arenaStatus = getArenaStatus();
                
                if (arenaBusy) {
                    showActionBar(player, `§eFila: ${position}º | ${arenaStatus.message}`);
                } else {
                    showActionBar(player, `§eFila PvP: ${position}º | Aguardando oponente...`);
                }
                
                if (!isEmpty(player)) {
                    removeFromQueue(player);
                }
            }
            
            if (fighting.includes(player) && fightActive && isValidEntity(player)) {
                if (!isInArena(player)) {
                    showActionBar(player, "§c§l⚠️ VOCÊ SAIU DA ARENA! ⚠️");
                    
                    const distance = getDistance(player.location, ARENA_CENTER);
                    if (distance > ARENA_RADIUS * 2) {
                        const winner = fighting.find(p => p !== player && isValidEntity(p));
                        endFight(winner, player, "TELEPORT_SAIU");
                    }
                } else {
                    const distance = getDistance(player.location, ARENA_CENTER);
                    if (distance > ARENA_RADIUS - 20) {
                        const blocksToBorder = Math.round(ARENA_RADIUS - distance);
                        showActionBar(player, `§e⚠️ Cuidado! §f${blocksToBorder} blocos até a borda`);
                    }
                }
            }
        }

        if (arenaBusy && fightActive && fightStartTime && system.currentTick - fightStartTime > 6000) {
            world.sendMessage("§c⚠️ A luta está demorando muito! Finalizando por segurança...");
            endFight(fighting[0], fighting[1], "TEMPO_ESGOTADO");
        }

        if (!arenaBusy && queue.length >= 2) {
            tryStartFight();
        }
    } catch (e) {}
}, 20);

/* ===== LÓGICA DE COMBATE ===== */

function tryStartFight() {
    if (arenaBusy || queue.length < 2) return;
    
    const p1 = queue[0];
    const p2 = queue[1];
    
    if (!isValidEntity(p1)) {
        queue.shift();
        return;
    }
    
    if (!isValidEntity(p2)) {
        queue.splice(1, 1);
        return;
    }
    
    if (!isEmpty(p1)) {
        removeFromQueue(p1);
        return;
    }
    
    if (!isEmpty(p2)) {
        removeFromQueue(p2);
        return;
    }
    
    arenaBusy = true;
    fightActive = false;
    
    queue.shift();
    queue.shift();

    fighting = [p1, p2];

    world.sendMessage(`§e⚔️ §f${getPlayerName(p1)} §evs §f${getPlayerName(p2)} §e- O duelo vai começar!`);

    let countdown = 3;
    const intervalId = system.runInterval(() => {
        try {
            if (!isValidEntity(p1) || !isValidEntity(p2)) {
                system.clearRun(intervalId);
                
                const winner = isValidEntity(p1) ? p1 : (isValidEntity(p2) ? p2 : null);
                const loser = !isValidEntity(p1) ? p1 : (!isValidEntity(p2) ? p2 : null);
                
                endFight(winner, loser, "WO_QUITOU");
                return;
            }
            
            if (countdown === 0) {
                system.clearRun(intervalId);
                
                if (isValidEntity(p1) && isValidEntity(p2)) {
                    runCommandForPlayer(p1, `tp @s ${ARENA_P1.x} ${ARENA_P1.y} ${ARENA_P1.z}`);
                    runCommandForPlayer(p2, `tp @s ${ARENA_P2.x} ${ARENA_P2.y} ${ARENA_P2.z}`);
                    
                    system.runTimeout(() => {
                        if (isValidEntity(p1) && isValidEntity(p2)) {
                            giveKit(p1);
                            giveKit(p2);
                            
                            // Adiciona tags de luta e autorização
                            addTag(p1, TAG_IN_FIGHT);
                            addTag(p1, TAG_ARENA_ALLOWED);
                            addTag(p2, TAG_IN_FIGHT);
                            addTag(p2, TAG_ARENA_ALLOWED);
                            
                            fightActive = true;
                            fightStartTime = system.currentTick;
                            startPositionCheck();
                            
                            showTitle(p1, "§c§lLUTA!", "§fMate seu oponente!");
                            showTitle(p2, "§c§lLUTA!", "§fMate seu oponente!");
                            
                            world.sendMessage(`§a✅ Luta iniciada! Raio: ${ARENA_RADIUS} blocos`);
                        }
                    }, 5);
                } else {
                    endFight(null, null, "ERRO");
                }
                return;
            }

            for (const p of [p1, p2]) {
                if (p && isValidEntity(p)) {
                    showTitle(p, `§c§l${countdown}`, "§ePrepare-se!");
                }
            }
            countdown--;
        } catch (e) {
            system.clearRun(intervalId);
            endFight(null, null, "ERRO");
        }
    }, 20);
}

/* ===== EVENTOS ===== */

/**
 * Quando jogador entra no servidor
 */
world.afterEvents.playerSpawn.subscribe(ev => {
    const player = ev.player;
    if (!player || !isValidEntity(player)) return;
    
    system.runTimeout(() => {
        checkAndCleanReconnectedPlayer(player);
    }, 40);
});

/**
 * NOVO: Verificação de movimento - para pegar jogadores que tentam entrar na arena
 */
world.afterEvents.playerDimensionChange.subscribe(ev => {
    const player = ev.player;
    if (!player || !isValidEntity(player)) return;
    
    system.runTimeout(() => {
        if (isInArena(player) && !isAllowedInArena(player)) {
            removeUnauthorizedFromArena(player);
        }
    }, 5);
});

/**
 * Escuta o comando /scriptevent manus:1v1
 */
system.afterEvents.scriptEventReceive.subscribe(ev => {
    if (ev.id !== "manus:1v1") return;

    const player = ev.sourceEntity;
    if (!player || !isValidEntity(player) || player.typeId !== "minecraft:player") return;

    try {
        if (hasTag(player, TAG_DISCONNECTED)) {
            checkAndCleanReconnectedPlayer(player);
        }
        
        if (queue.includes(player)) {
            queue = queue.filter(p => p !== player);
            showTitle(player, "§c§lFILA", "§fVocê saiu da fila de PvP!");
            return;
        }

        if (!isEmpty(player)) {
            showTitle(player, "§c§lERRO", "§fInventário deve estar vazio!");
            return;
        }

        queue.push(player);
        const position = queue.length;
        showTitle(player, "§a§lNA FILA", `§fPosição: ${position}º`);
        
        const arenaStatus = getArenaStatus();
        if (arenaBusy) {
            showActionBar(player, `§e${arenaStatus.message}`);
            player.sendMessage(`§eℹ️ ${arenaStatus.message}`);
        } else {
            player.sendMessage(`§a✅ Arena disponível! Aguardando oponente...`);
        }
        
        if (queue.length > 1) {
            player.sendMessage(`§7Há ${queue.length} jogador(es) na fila.`);
        }
    } catch (e) {}
});

/**
 * Comando para ver status
 */
system.afterEvents.scriptEventReceive.subscribe(ev => {
    if (ev.id !== "manus:1v1status") return;

    const player = ev.sourceEntity;
    
    try {
        let message = "§6=== STATUS DA ARENA ===\n";
        message += `${getArenaStatus().message}\n`;
        message += `§7Jogadores na fila: §f${queue.length}\n`;
        
        if (fighting.length > 0) {
            const status = fightActive ? "§cEm luta" : "§ePreparando";
            message += `§7Status: ${status}\n`;
            message += `§7Em luta: §f${fighting.map(p => getPlayerName(p)).join(" §7vs §f")}\n`;
            
            if (fightActive) {
                for (const fighter of fighting) {
                    if (fighter && isValidEntity(fighter)) {
                        const distance = getDistance(fighter.location, ARENA_CENTER);
                        const inArena = distance <= ARENA_RADIUS;
                        const status = inArena ? "§a✓ Dentro" : "§c✗ Fora";
                        message += `§7  ${getPlayerName(fighter)}: ${status} (§f${Math.round(distance)}m§7)\n`;
                    }
                }
            }
            message += `§7Raio: §f${ARENA_RADIUS} blocos\n`;
        }
        
        if (player) {
            player.sendMessage(message);
        } else {
            world.sendMessage(message);
        }
    } catch (e) {}
});

/**
 * Comando para dar tag de autorização manual (para admins)
 */
system.afterEvents.scriptEventReceive.subscribe(ev => {
    if (ev.id !== "manus:1v1admin") return;

    const player = ev.sourceEntity;
    if (!player || !isValidEntity(player)) return;
    
    const args = ev.message?.split(" ") || [];
    
    if (args[0] === "allow" && args[1]) {
        // Procura jogador pelo nome
        const target = world.getAllPlayers().find(p => 
            getPlayerName(p).toLowerCase().includes(args[1].toLowerCase())
        );
        
        if (target) {
            addTag(target, TAG_ARENA_ALLOWED);
            player.sendMessage(`§a✅ Tag de autorização adicionada para ${getPlayerName(target)}`);
        }
    } else if (args[0] === "clear") {
        if (args[1]) {
            const target = world.getAllPlayers().find(p => 
                getPlayerName(p).toLowerCase().includes(args[1].toLowerCase())
            );
            if (target) {
                removeTag(target, TAG_ARENA_ALLOWED);
                player.sendMessage(`§c❌ Tag de autorização removida de ${getPlayerName(target)}`);
            }
        } else {
            removeTag(player, TAG_ARENA_ALLOWED);
            player.sendMessage("§c❌ Sua tag de autorização foi removida");
        }
    }
});



/**
 * Detecta morte
 */
world.afterEvents.entityDie.subscribe(ev => {
    const dead = ev.deadEntity;
    if (!dead || dead.typeId !== "minecraft:player") return;
    
    if (!fighting.includes(dead) || !fightActive) return;

    const winner = fighting.find(p => p !== dead && isValidEntity(p));
    system.runTimeout(() => endFight(winner, dead, "MORTE"), 40);
});



/**
 * Quando jogador sai
 */
world.beforeEvents.playerLeave.subscribe(ev => {
    const player = ev.player;
    const playerName = getPlayerName(player);
    
    if (fighting.includes(player)) {
        addTag(player, TAG_DISCONNECTED);
        console.log(`[PvP System] Tag ${TAG_DISCONNECTED} adicionada para ${playerName}`);
    }
    
    queue = queue.filter(p => p !== player);
    
    if (fighting.includes(player)) {
        const winner = fighting.find(p => p !== player && isValidEntity(p));
        
        system.run(() => {
            try {
                endFight(winner, player, "WO_QUITOU");
            } catch (e) {
                arenaBusy = false;
                fightActive = false;
                fighting = [];
                fightStartTime = null;
                if (positionCheckInterval) {
                    system.clearRun(positionCheckInterval);
                    positionCheckInterval = null;
                }
                world.sendMessage(`§c⚠️ Jogador desconectou! Arena liberada.`);
            }
        });
    }
});

// Limpeza periódica
const tagCleanupInterval = system.runInterval(() => {
    cleanupAllTags();
}, 6000);

// Limpeza ao descarregar
if (typeof system.beforeEvents?.shutdown !== "undefined") {
    system.beforeEvents.shutdown.subscribe(() => {
        if (actionBarInterval) {
            system.clearRun(actionBarInterval);
            actionBarInterval = null;
        }
        if (positionCheckInterval) {
            system.clearRun(positionCheckInterval);
            positionCheckInterval = null;
        }
        if (tagCleanupInterval) {
            system.clearRun(tagCleanupInterval);
        }
    });
}

console.log("[PvP System] Carregado com sucesso!");
console.log("  /scriptevent manus:1v1 - Entrar/sair da fila");
console.log("  /scriptevent manus:1v1status - Ver status");
console.log("  /scriptevent manus:1v1admin allow <nome> - Autorizar jogador (admin)");
console.log("  /scriptevent manus:1v1admin clear <nome> - Remover autorização");
console.log(`  Raio da arena: ${ARENA_RADIUS} blocos - PROTEÇÃO ATIVA!`);
console.log(`  Tags: ${TAG_DISCONNECTED}, ${TAG_IN_FIGHT}, ${TAG_ARENA_ALLOWED}`);